#!/usr/bin/env python3
import os, sys, time, subprocess
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, '/opt/waveshare-mini')
UPS = os.getenv('UPS_NAME', 'GOLDENMATE')
INT_AC = int(os.getenv('INTERVAL_AC', '60'))
INT_BATT = int(os.getenv('INTERVAL_BATT', '20'))
FULL_REFRESH_EVERY = int(os.getenv('FULL_REFRESH_EVERY', '30'))

from waveshare_epd import epd2in13_V4, epd2in13_V3

def get_data():
    p = subprocess.run(['upsc', f'{UPS}@localhost'], capture_output=True, text=True, timeout=10)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.strip() or 'upsc failed')
    d = {}
    for ln in p.stdout.splitlines():
        if ':' in ln:
            k, v = ln.split(':', 1)
            d[k.strip()] = v.strip()
    return d

def ff(v):
    try: return float(v)
    except: return None

def hhmm(s):
    if s is None: return '--:--'
    s = int(s)
    return f'{s//3600:02d}:{(s%3600)//60:02d}'

def load_fonts():
    try:
        big = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 48)
        med = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 20)
        sml = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 14)
        return big, med, sml
    except Exception:
        d = ImageFont.load_default()
        return d, d, d

def draw_screen(w, h, d, fbig, fmed, fsml):
    if w < h:
        w, h = h, w
    img = Image.new('1', (w, h), 255)
    dr = ImageDraw.Draw(img)

    st = d.get('ups.status', '?')
    ch = ff(d.get('battery.charge'))
    rt = ff(d.get('battery.runtime'))

    dr.text((8, 0), 'RUNTIME', font=fsml, fill=0)
    dr.text((6, 14), hhmm(rt), font=fbig, fill=0)

    badge = 'ON BAT' if 'OB' in st else 'ONLINE'
    bw = 82
    dr.rectangle((w-bw-6, 4, w-6, 28), outline=0, fill=0)
    dr.text((w-bw+6, 9), badge, font=fsml, fill=255)

    dr.line((0, 66, w, 66), fill=0, width=1)
    dr.text((8, 74), f'BATTERY {int(ch) if ch is not None else "?"}%', font=fmed, fill=0)
    dr.text((8, 100), f'{datetime.now().strftime("%Y-%m-%d %H:%M")}', font=fsml, fill=0)
    return img

epd = None
for m in (epd2in13_V4, epd2in13_V3):
    try:
        epd = m.EPD()
        break
    except Exception:
        pass
if epd is None:
    raise SystemExit('No 2.13 V3/V4 driver found')

epd.init()
try:
    epd.Clear(0xFF)
except Exception:
    pass

fbig, fmed, fsml = load_fonts()
last = ''
loops = 0

while True:
    try:
        d = get_data()
        st = d.get('ups.status', '?')
        key = '|'.join(d.get(k,'') for k in ['ups.status','battery.charge','battery.runtime'])
        changed = key != last
        loops += 1

        if changed or loops % FULL_REFRESH_EVERY == 0:
            w = getattr(epd, 'height', 250)
            h = getattr(epd, 'width', 122)
            img = draw_screen(w, h, d, fbig, fmed, fsml)
            buf = epd.getbuffer(img)
            if loops % FULL_REFRESH_EVERY == 0:
                epd.display(buf)
            else:
                if hasattr(epd, 'displayPartial'):
                    epd.displayPartial(buf)
                else:
                    epd.display(buf)
            last = key

        time.sleep(INT_BATT if 'OB' in st else INT_AC)
    except Exception:
        time.sleep(15)

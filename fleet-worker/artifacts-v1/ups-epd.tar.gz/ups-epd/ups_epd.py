#!/usr/bin/env python3
import os, sys, time, subprocess, json
from datetime import datetime, timezone
from PIL import Image, ImageDraw, ImageFont
try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None

sys.path.insert(0, '/opt/waveshare-mini')
UPS = os.getenv('UPS_NAME', 'GOLDENMATE')
INT_AC = int(os.getenv('INTERVAL_AC', '60'))
INT_BATT = int(os.getenv('INTERVAL_BATT', '20'))
# Periodic full refresh cadence; 0 disables periodic full refresh.
FULL_REFRESH_EVERY = int(os.getenv('FULL_REFRESH_EVERY', '0'))
DISPLAY_TZ = os.getenv('DISPLAY_TZ', 'America/Los_Angeles')
# Transition stabilization delays (seconds) before re-sampling/drawing.
# OL -> OB can usually be short; OB -> OL may need longer settling.
TRANSITION_DELAY_TO_BATT = float(os.getenv('TRANSITION_DELAY_TO_BATT', '1.0'))
TRANSITION_DELAY_TO_AC = float(os.getenv('TRANSITION_DELAY_TO_AC', '10.0'))
ESTIMATE_ONLINE_RUNTIME = os.getenv('ESTIMATE_ONLINE_RUNTIME', '1') == '1'
MODEL_STATE_PATH = os.getenv('MODEL_STATE_PATH', '/var/lib/ups-epd/runtime_model.json')
MODEL_ALPHA = float(os.getenv('MODEL_ALPHA', '0.2'))
MODEL_MIN_WATTS = float(os.getenv('MODEL_MIN_WATTS', '20'))
UPS_RATED_WATTS = float(os.getenv('UPS_RATED_WATTS', '0'))

from waveshare_epd import epd2in13_V4, epd2in13_V3

def get_data():
    p = subprocess.run(['upsc', f'{UPS}@localhost'], capture_output=True, text=True, timeout=10)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.strip() or 'upsc failed')
    d = {}
    for ln in p.stdout.splitlines():
        if ':' in ln:
            k, v = ln.split(':', 1)
            d[k.strip()] = v.strip()
    return d

def ff(v):
    try: return float(v)
    except: return None

def hhmm(s):
    if s is None: return '--:--'
    s = int(max(0, s))
    return f'{s//3600:02d}:{(s%3600)//60:02d}'

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def load_model_state(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            d = json.load(f)
        if isinstance(d, dict):
            return d
    except Exception:
        pass
    return {'usable_wh': None, 'samples': 0, 'updated_at': 0}

def save_model_state(path, state):
    try:
        d = os.path.dirname(path)
        if d:
            os.makedirs(d, exist_ok=True)
        tmp = f"{path}.tmp"
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(state, f)
        os.replace(tmp, path)
    except Exception:
        pass

def estimate_output_watts(d):
    # Prefer direct power keys if available.
    for k in ('output.realpower', 'ups.realpower', 'output.power', 'ups.power'):
        w = ff(d.get(k))
        if w is not None and w > 0:
            return w
    # Fallback: load percentage * configured rated watts.
    load_pct = ff(d.get('ups.load'))
    if load_pct is not None and UPS_RATED_WATTS > 0:
        return (load_pct / 100.0) * UPS_RATED_WATTS
    return None

def learn_usable_wh_from_ob(d, state):
    soc = ff(d.get('battery.charge'))
    rt = ff(d.get('battery.runtime'))
    w = estimate_output_watts(d)
    if soc is None or rt is None or w is None:
        return False
    soc01 = soc / 100.0
    if soc01 <= 0.05 or soc01 > 1.0:
        return False
    if rt < 60 or w < MODEL_MIN_WATTS:
        return False
    sample_wh = (w * rt / 3600.0) / soc01
    sample_wh = clamp(sample_wh, 20.0, 5000.0)

    prev = state.get('usable_wh')
    if prev is None:
        state['usable_wh'] = sample_wh
    else:
        a = clamp(MODEL_ALPHA, 0.01, 0.8)
        state['usable_wh'] = (1 - a) * float(prev) + a * sample_wh
    state['samples'] = int(state.get('samples', 0)) + 1
    state['updated_at'] = int(time.time())
    return True

def estimate_online_runtime_seconds(d, state):
    usable_wh = ff(state.get('usable_wh'))
    if usable_wh is None:
        return None
    soc = ff(d.get('battery.charge'))
    w = estimate_output_watts(d)
    if soc is None or w is None or w < MODEL_MIN_WATTS:
        return None
    soc01 = clamp(soc / 100.0, 0.0, 1.0)
    return (usable_wh * soc01 / w) * 3600.0

def manufacturer_key(d):
    parts = [
        d.get('ups.mfr', ''),
        d.get('device.mfr', ''),
        d.get('ups.model', ''),
        d.get('device.model', ''),
    ]
    return ' '.join(parts).lower()

def is_goldenmate(d):
    m = manufacturer_key(d)
    # Goldenmate units observed in field can surface as GOLDENMATE or -BMS- smart-battery strings.
    return ('goldenmate' in m) or ('-bms-' in m and 'smart-battery' in m)

def display_now_str():
    now_utc = datetime.now(timezone.utc)
    if ZoneInfo is not None:
        try:
            return now_utc.astimezone(ZoneInfo(DISPLAY_TZ)).strftime("%Y-%m-%d %H:%M")
        except Exception:
            pass
    return now_utc.strftime("%Y-%m-%d %H:%M UTC")

def load_fonts():
    try:
        big = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 48)
        med = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 20)
        sml = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 14)
        return big, med, sml
    except Exception:
        d = ImageFont.load_default()
        return d, d, d

def draw_no_ups(w, h, ups, err, fbig, fmed, fsml):
    # Shown when upsc can't reach the UPS (not plugged in, nut-driver down,
    # wrong section name). Previously the loop swallowed the exception and
    # left the e-ink blank after the startup Clear(0xFF), which looks like
    # the device is dead. A visible placeholder tells the operator the Pi
    # is running and what it's waiting on.
    if w < h:
        w, h = h, w
    img = Image.new('1', (w, h), 255)
    dr = ImageDraw.Draw(img)
    host = os.uname().nodename
    dr.text((8, 0), 'NO UPS', font=fsml, fill=0)
    dr.text((6, 14), 'WAITING', font=fmed, fill=0)
    dr.line((0, 46, w, 46), fill=0, width=1)
    dr.text((8, 52), f'name: {ups}', font=fsml, fill=0)
    short_err = (err or '').splitlines()[0][:32] if err else ''
    if short_err:
        dr.text((8, 70), short_err, font=fsml, fill=0)
    dr.text((8, 88), host[:22], font=fsml, fill=0)
    dr.text((8, 104), display_now_str(), font=fsml, fill=0)
    return img

def draw_screen(w, h, d, fbig, fmed, fsml):
    if w < h:
        w, h = h, w
    img = Image.new('1', (w, h), 255)
    dr = ImageDraw.Draw(img)

    st = d.get('ups.status', '?')
    ch = ff(d.get('battery.charge'))
    rt = ff(d.get('battery.runtime'))

    # Runtime display policy (manufacturer-based):
    # - Default: show runtime as reported.
    # - Goldenmate family: on line power use learned estimate when available.
    show_rt = ff(d.get('_runtime_display'))
    if show_rt is None:
        show_rt = rt
        if is_goldenmate(d) and 'OB' not in st:
            show_rt = None

    dr.text((8, 0), 'RUNTIME', font=fsml, fill=0)
    dr.text((6, 14), hhmm(show_rt), font=fbig, fill=0)

    bw = 82
    x1, x2 = (w-bw-6, w-6)

    # Positional status cue:
    # - ONLINE box in upper-right
    # - BAT box in lower-right (still above separator line)
    if 'OB' in st:
        y1, y2 = 34, 58
        badge = 'BAT'
        text_y = 39
    else:
        y1, y2 = 4, 28
        badge = 'ONLINE'
        text_y = 9

    dr.rectangle((x1, y1, x2, y2), outline=0, fill=0)
    dr.text((x1+6, text_y), badge, font=fsml, fill=255)

    dr.line((0, 66, w, 66), fill=0, width=1)
    dr.text((8, 74), f'BATTERY {int(ch) if ch is not None else "?"}%', font=fmed, fill=0)
    dr.text((8, 100), display_now_str(), font=fsml, fill=0)
    return img

epd = None
for m in (epd2in13_V4, epd2in13_V3):
    try:
        epd = m.EPD()
        break
    except Exception:
        pass
if epd is None:
    raise SystemExit('No 2.13 V3/V4 driver found')

epd.init()
try:
    epd.Clear(0xFF)
except Exception:
    pass

fbig, fmed, fsml = load_fonts()
last = ''
loops = 0
first_draw = True
prev_on_battery = None
model_state = load_model_state(MODEL_STATE_PATH)

while True:
    try:
        d = get_data()
        st = d.get('ups.status', '?')
        on_battery = ('OB' in st)

        # Learn model from on-battery samples; estimate runtime on line power.
        if is_goldenmate(d):
            if on_battery:
                if learn_usable_wh_from_ob(d, model_state):
                    save_model_state(MODEL_STATE_PATH, model_state)
            elif ESTIMATE_ONLINE_RUNTIME:
                est = estimate_online_runtime_seconds(d, model_state)
                if est is not None:
                    d['_runtime_display'] = est

        rt_disp = ff(d.get('_runtime_display'))
        key = '|'.join([
            d.get('ups.status', ''),
            d.get('battery.charge', ''),
            d.get('battery.runtime', ''),
            str(int(rt_disp)) if rt_disp is not None else '-1'
        ])
        changed = key != last
        loops += 1

        power_state_changed = (prev_on_battery is not None and on_battery != prev_on_battery)
        periodic_full = FULL_REFRESH_EVERY > 0 and (loops % FULL_REFRESH_EVERY == 0)
        if changed or periodic_full or first_draw:
            # On power-source transition, re-sample once after a stabilization delay
            # so we draw settled NUT values (avoids stale pre-transition payload).
            if power_state_changed:
                # Transition into AC (OB -> OL) often settles slower than OL -> OB.
                settle_delay = TRANSITION_DELAY_TO_AC if not on_battery else TRANSITION_DELAY_TO_BATT
                time.sleep(settle_delay)
                d = get_data()
                st = d.get('ups.status', '?')
                on_battery = ('OB' in st)
                if is_goldenmate(d):
                    if on_battery:
                        if learn_usable_wh_from_ob(d, model_state):
                            save_model_state(MODEL_STATE_PATH, model_state)
                    elif ESTIMATE_ONLINE_RUNTIME:
                        est = estimate_online_runtime_seconds(d, model_state)
                        if est is not None:
                            d['_runtime_display'] = est

            w = getattr(epd, 'height', 250)
            h = getattr(epd, 'width', 122)
            img = draw_screen(w, h, d, fbig, fmed, fsml)
            buf = epd.getbuffer(img)

            # Always do one clean full refresh at startup, on periodic cycle,
            # or when switching power source (OL <-> OB) to avoid ghosting.
            if first_draw or periodic_full or power_state_changed:
                epd.display(buf)
            else:
                if hasattr(epd, 'displayPartial'):
                    epd.displayPartial(buf)
                else:
                    epd.display(buf)

            first_draw = False
            prev_on_battery = on_battery
            last = key

        time.sleep(INT_BATT if 'OB' in st else INT_AC)
    except Exception as e:
        err_msg = str(e)
        key = f'NOUPS|{err_msg[:64]}'
        loops += 1
        periodic_full = FULL_REFRESH_EVERY > 0 and (loops % FULL_REFRESH_EVERY == 0)
        if key != last or periodic_full or first_draw:
            try:
                w = getattr(epd, 'height', 250)
                h = getattr(epd, 'width', 122)
                img = draw_no_ups(w, h, UPS, err_msg, fbig, fmed, fsml)
                buf = epd.getbuffer(img)
                if first_draw or periodic_full or not hasattr(epd, 'displayPartial'):
                    epd.display(buf)
                else:
                    epd.displayPartial(buf)
                first_draw = False
                last = key
            except Exception:
                pass
        time.sleep(15)
